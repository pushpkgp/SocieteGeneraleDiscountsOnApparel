package com.societe.generale.problem.category.MenWear;

import com.societe.generale.problem.utils.AppConstants;
import com.societe.generale.problem.utils.DiscountCalculator;

/**
 * Casuals subcategory that extends "MenWear" category.
 */
public abstract class Casuals extends MenWear {

    private final String subCategory = AppConstants.CASUALS;
    private final int discount = AppConstants.CASUALS_DISC;

    public String  subCategory(){
        return this.subCategory;
    }

    @Override
    public int discount() {
        return DiscountCalculator.discountCalculator(this.discount, super.discount());
    }
}